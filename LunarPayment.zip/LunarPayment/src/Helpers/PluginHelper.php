<?php

namespace Lunar\Payment\Helpers;

class PluginHelper
{
    // generated with \Shopware\Core\Framework\Uuid\Uuid::randomHex()
    public const PAYMENT_METHOD_UUID = '1a9bc76a3c244278a51a2e90c1e6f040';

    public const VENDOR_NAME = 'lunar';

    public const PLUGIN_CODE = 'LunarPayment';
    public const PAYMENT_METHOD_NAME = 'Card';

    public const TRANSACTION_MODE = 'live';
    public const CAPTURE_MODE = 'delayed';
    public const PAYMENT_METHOD_DESCRIPTION = 'Secure payment with credit card via © Lunar';
    public const ACCEPTED_CARDS = ['visa', 'visaelectron', 'mastercard', 'maestro'];

    public const PLUGIN_CONFIG_PATH = self::PLUGIN_CODE . '.config.';

    public static function getPluginVersion() 
    {
        // Cannot use \Composer\InstalledVersions::getRootPackage()['version'] right now
        return json_decode(file_get_contents('../../composer.json'))->version;
    }
}
