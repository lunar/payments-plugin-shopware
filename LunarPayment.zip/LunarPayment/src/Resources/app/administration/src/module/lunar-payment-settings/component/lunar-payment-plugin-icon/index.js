import template from './lunar-payment-plugin-icon.html.twig';
import './lunar-payment-plugin-icon.scss';

Shopware.Component.register('lunar-payment-plugin-icon', {
    template
});
